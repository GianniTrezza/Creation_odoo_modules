from odoo import models, api, fields, _

class ResPartner(models.Model):
    _inherit = "res.partner"

    is_accreditata = fields.Boolean(string='Accreditata')

class HospitalAccreditation(models.Model):
    _name = 'hospital.accreditation'
    _description = 'Accreditation of Healthcare Structures'
    
    @api.model
    def _get_default_user(self):
        return self.env.user.id

    codice_pratica = fields.Char(string='Codice Pratica', readonly=True, copy=False, default=lambda self: _('New'))
    autore_registrazione = fields.Many2one('res.users', string='Autore Registrazione', default=_get_default_user, readonly=True)
    tipologia_pratica_id = fields.Many2one('hospital.tipologia_pratica', string='Tipologia Pratica', required=True)
    richiedente_id = fields.Many2one('res.partner', string='Richiedente', domain=[('is_company', '=', False)])
    struttura_da_accreditare_id = fields.Many2one('res.partner', string='Struttura da Accreditare', domain=[('is_company', '=', True), ('is_struttura_sanitaria', '=', True)], required=True)
    descrizione = fields.Html(string='Descrizione')
    state = fields.Selection([
    ('draft', 'bozza'),
    ('recorded', 'In compilazione'),
    ('to be approved', 'Da approvare'),
    ('approved', 'Approvato'),
    ('refused', 'Rifiutato'),
], string='Stato', default='draft', readonly=True)

    @api.model
    def create(self, vals):
        if vals.get('codice_pratica', _('New')) == _('New'):
            vals['codice_pratica'] = self.env['ir.sequence'].next_by_code('hospital.accreditation.sequence') or _('New')
        result = super(HospitalAccreditation, self).create(vals)
        return result
    

    @api.model
    def button_recorded(self):
        for record in self:
            record.state = "recorded"
        return True

    @api.model
    def button_to_be_approved(self):
        for record in self:
            record.state = "to be approved"
        return True

    @api.model
    def button_approve(self):
        for record in self:
            record.state = 'approved'
            record.struttura_da_accreditare_id.is_accreditata = True
        return True

    @api.model
    def button_refuse(self):
        for record in self:
            record.state = 'refused'
        return True
